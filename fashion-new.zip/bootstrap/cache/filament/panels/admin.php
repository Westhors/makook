<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.design-resource.pages.create-design' => 'App\\Filament\\Resources\\DesignResource\\Pages\\CreateDesign',
    'app.filament.resources.design-resource.pages.edit-design' => 'App\\Filament\\Resources\\DesignResource\\Pages\\EditDesign',
    'app.filament.resources.design-resource.pages.list-designs' => 'App\\Filament\\Resources\\DesignResource\\Pages\\ListDesigns',
    'app.filament.resources.filament.widgets-resource.widgets.dashboard-stats' => 'App\\Filament\\Resources\\Filament\\WidgetsResource\\Widgets\\DashboardStats',
    'app.filament.resources.filament.widgets-resource.widgets.design-stats' => 'App\\Filament\\Resources\\Filament\\WidgetsResource\\Widgets\\DesignStats',
    'app.filament.resources.filament.widgets-resource.widgets.hood-stats' => 'App\\Filament\\Resources\\Filament\\WidgetsResource\\Widgets\\HoodStats',
    'app.filament.resources.filament.widgets-resource.widgets.robe-stats' => 'App\\Filament\\Resources\\Filament\\WidgetsResource\\Widgets\\RobeStats',
    'app.filament.resources.filament.widgets-resource.widgets.scarf-stats' => 'App\\Filament\\Resources\\Filament\\WidgetsResource\\Widgets\\ScarfStats',
    'app.filament.resources.hood-resource.pages.create-hood' => 'App\\Filament\\Resources\\HoodResource\\Pages\\CreateHood',
    'app.filament.resources.hood-resource.pages.edit-hood' => 'App\\Filament\\Resources\\HoodResource\\Pages\\EditHood',
    'app.filament.resources.hood-resource.pages.list-hoods' => 'App\\Filament\\Resources\\HoodResource\\Pages\\ListHoods',
    'app.filament.resources.none-resource.widgets.design-stats' => 'App\\Filament\\Resources\\NoneResource\\Widgets\\DesignStats',
    'app.filament.resources.robe-resource.pages.create-robe' => 'App\\Filament\\Resources\\RobeResource\\Pages\\CreateRobe',
    'app.filament.resources.robe-resource.pages.edit-robe' => 'App\\Filament\\Resources\\RobeResource\\Pages\\EditRobe',
    'app.filament.resources.robe-resource.pages.list-robes' => 'App\\Filament\\Resources\\RobeResource\\Pages\\ListRobes',
    'app.filament.resources.scarf-resource.pages.create-scarf' => 'App\\Filament\\Resources\\ScarfResource\\Pages\\CreateScarf',
    'app.filament.resources.scarf-resource.pages.edit-scarf' => 'App\\Filament\\Resources\\ScarfResource\\Pages\\EditScarf',
    'app.filament.resources.scarf-resource.pages.list-scarves' => 'App\\Filament\\Resources\\ScarfResource\\Pages\\ListScarves',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'filament.widgets.account-widget' => 'Filament\\Widgets\\AccountWidget',
    'filament.widgets.filament-info-widget' => 'Filament\\Widgets\\FilamentInfoWidget',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.pages.auth.login' => 'Filament\\Pages\\Auth\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'C:\\laragon\\www\\fashion-new\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'C:\\laragon\\www\\fashion-new\\app\\Filament\\Resources\\DesignResource.php' => 'App\\Filament\\Resources\\DesignResource',
    'C:\\laragon\\www\\fashion-new\\app\\Filament\\Resources\\HoodResource.php' => 'App\\Filament\\Resources\\HoodResource',
    'C:\\laragon\\www\\fashion-new\\app\\Filament\\Resources\\RobeResource.php' => 'App\\Filament\\Resources\\RobeResource',
    'C:\\laragon\\www\\fashion-new\\app\\Filament\\Resources\\ScarfResource.php' => 'App\\Filament\\Resources\\ScarfResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'C:\\laragon\\www\\fashion-new\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    0 => 'Filament\\Widgets\\AccountWidget',
    1 => 'Filament\\Widgets\\FilamentInfoWidget',
    2 => 'App\\Filament\\Resources\\Filament\\WidgetsResource\\Widgets\\DesignStats',
    3 => 'App\\Filament\\Resources\\Filament\\WidgetsResource\\Widgets\\RobeStats',
    4 => 'App\\Filament\\Resources\\Filament\\WidgetsResource\\Widgets\\HoodStats',
    5 => 'App\\Filament\\Resources\\Filament\\WidgetsResource\\Widgets\\ScarfStats',
  ),
  'widgetDirectories' => 
  array (
    0 => 'C:\\laragon\\www\\fashion-new\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);