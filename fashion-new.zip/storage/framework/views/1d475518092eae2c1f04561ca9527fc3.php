<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>
    <meta charset="UTF-8">
    <title>فاتورة التصميم</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            padding: 40px;
            direction: rtl;
        }

        .invoice-box {
            width: 100%;
            border: 1px solid #eee;
            padding: 30px;
            box-shadow: 0 0 10px rgba(0, 0, 0, .15);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            margin-bottom: 20px;
        }

        td {
            padding: 5px 0;
        }

        .footer {
            text-align: center;
            margin-top: 40px;
            font-size: 14px;
        }

        @media print {
            .no-print {
                display: none;
            }
        }
    </style>
</head>

<body>
    <div class="invoice-box">
        <h2>فاتورة التصميم</h2>

        <table>
            <tr>
                <td><strong>رقم الطلب:</strong> <?php echo e($design->id); ?></td>
                <td><strong>تاريخ الطلب:</strong> <?php echo e($design->created_at->format('Y-m-d')); ?></td>
            </tr>
            <tr>
                <td><strong>نوع التصميم:</strong>
                    <?php echo e($design->design_type === 'individual' ? 'تصميم فردي' : 'تصميم دفعة'); ?></td>
                <td><strong>اللون:</strong> <?php echo e($design->color); ?></td>
            </tr>
            <tr>
                <td><strong>عرض الكتف:</strong> <?php echo e($design->shoulder_width); ?></td>
                <td><strong>طول الذراع:</strong> <?php echo e($design->arm_length); ?></td>
            </tr>
            <tr>
                <td><strong>الطول الكلي:</strong> <?php echo e($design->total_length); ?></td>
                <td><strong>الروب:</strong> <?php echo e($design->robe?->name ?? '-'); ?></td>
            </tr>
            <tr>
                <td><strong>القبعة:</strong> <?php echo e($design->hood?->name ?? '-'); ?></td>
                <td><strong>الوشاح:</strong> <?php echo e($design->scarf?->name ?? '-'); ?></td>
            </tr>
            <tr>
                <td colspan="2"><strong>السعر الإجمالي:</strong> <?php echo e(number_format($design->total_price, 2)); ?> ريال
                </td>
            </tr>
        </table>

        <div class="no-print">
            <button onclick="window.print()">🖨 طباعة</button>
        </div>
    </div>

    <div class="footer no-print">
        <p>شكراً لاستخدامك خدمتنا ❤️</p>
    </div>
</body>

</html>
<?php /**PATH C:\laragon\www\fashion-new\resources\views\filament\resources\design-resource\invoice.blade.php ENDPATH**/ ?>