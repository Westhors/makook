<?php

namespace App\Filament\Resources\ScarfResource\Pages;

use App\Filament\Resources\ScarfResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateScarf extends CreateRecord
{
    protected static string $resource = ScarfResource::class;
}
