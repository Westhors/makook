<?php

namespace App\Filament\Resources\HoodResource\Pages;

use App\Filament\Resources\HoodResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateHood extends CreateRecord
{
    protected static string $resource = HoodResource::class;
}
