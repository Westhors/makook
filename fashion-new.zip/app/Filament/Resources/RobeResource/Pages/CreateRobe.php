<?php

namespace App\Filament\Resources\RobeResource\Pages;

use App\Filament\Resources\RobeResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateRobe extends CreateRecord
{
    protected static string $resource = RobeResource::class;
}
